create_clock -name vpu_clk -period 3.333333 [get_ports clock]
